# Organisez vos composants en strates, laissez Express gérer ses responsabilités

<br/><br/>

 ### Séparez le code des composants en strates : web, services et couche d'accès aux données (DAL)

![alt text](../../assets/images/structurebycomponents.PNG "Séparez le code des composants en strates")

 <br/><br/>

### Explication en 1 min : l'inconvénient de mélanger les strates

![alt text](../../assets/images/keepexpressinweb.gif "L'inconvénient de mélanger les strates")

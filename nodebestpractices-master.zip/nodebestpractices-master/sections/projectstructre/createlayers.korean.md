# 컴포넌트를 계층화(layer)하고, Express를 그 경계 안에 둬라

<br/><br/>

 ### 컴포넌트 코드를 웹, 서비스, 데이터 접근 언어(DAL) 계층으로 나누어라

![alt text](../../assets/images/structurebycomponents.PNG "Separate component code into layers")

 <br/><br/>

### 1분 설명: 계층을 섞으면 불리한 점

![alt text](../../assets/images/keepexpressinweb.gif "The downside of mixing layers")

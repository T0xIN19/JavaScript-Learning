# アプリケーションを階層化し、 Express を境界内に収める

<br/><br/>

 ### コンポーネントコードをウェブ、サービス、DAL のレイヤーに分ける

![alt text](../../assets/images/structurebycomponents.PNG "コンポーネントコードを階層化する")

 <br/><br/>

### 1分解説: レイヤーを混ぜることのデメリット

![alt text](../../assets/images/keepexpressinweb.gif "レイヤーを混ぜることのデメリット")
